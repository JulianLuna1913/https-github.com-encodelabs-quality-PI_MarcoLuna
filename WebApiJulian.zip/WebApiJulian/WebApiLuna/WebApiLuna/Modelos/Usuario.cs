﻿namespace WebApiJulianLuna.Models;

public class Usuario
{
    //Creamos la clase Usuario y le asignamos sus atributos,
    public int Id { get; set; }
    public required string Nombre { get; set; } // (Nombre, Email, Password) son elementos requeridos.
    public required string Email { get; set; }
    public required string Password { get; set; }
}
