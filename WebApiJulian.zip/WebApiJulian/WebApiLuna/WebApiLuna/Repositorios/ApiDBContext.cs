﻿namespace WebApiJulianLuna.Repositories
{
    internal class ApiDBContext
    {
    }
}