﻿using Microsoft.EntityFrameworkCore;
using WebApiJulianLuna.Models;

namespace WebApiJulianLuna.Context
{
    public class AppDbContext : DbContext
    {
        //Creamos un constructor que contenga el DBcontex
        public AppDbContext(DbContextOptions<AppDbContext>options): base(options) 
        {
                
        }
        public DbSet<Usuario> Usuarios { get; set; }
    }
}
