Create database Usuario_DB;
show tables;
Use Usuario_DB;
Create table usuarios(
 id int primary KEY auto_increment,
 nombre varchar(100) not null,
 email varchar(100) not null,
 password int
);
show tables;
 Describe usuario_db;
 alter table usuarios modify COLUMN password varchar(255);